package com.smart_jobs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartJobsApplicationTests {

	@Test
	void contextLoads() {
	}

}
