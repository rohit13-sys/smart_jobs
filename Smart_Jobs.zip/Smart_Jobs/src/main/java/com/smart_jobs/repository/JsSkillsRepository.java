package com.smart_jobs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smart_jobs.web.model.JsSkills;

public interface JsSkillsRepository extends JpaRepository<JsSkills, Long>{

}
